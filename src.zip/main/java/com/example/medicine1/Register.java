package com.example.medicine1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.FirebaseDatabase;

import java.util.concurrent.TimeUnit;

public class Register extends AppCompatActivity {
    EditText Name, Email, RPass, RpassCheck, Phone, Code;
    Button ComRegi, CheckNum, Check;
    FirebaseAuth firebaseAuth;



    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_layout);

        firebaseAuth = FirebaseAuth.getInstance();
        Name = (EditText)findViewById(R.id.ET_Name);
        Email = (EditText)findViewById(R.id.ET_Mail);
        RPass = (EditText)findViewById(R.id.ET_RPassword);
        RpassCheck = (EditText)findViewById(R.id.ET_RPassword_Check);
        Phone = (EditText)findViewById(R.id.ET_PhoneNum);
        Code = (EditText)findViewById(R.id.ET_Code);
        ComRegi = (Button)findViewById(R.id.BT_ComRegi);
        CheckNum = (Button)findViewById(R.id.BT_CheckPhone);
        Check = (Button)findViewById(R.id.BT_Check);

        ComRegi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                runRegister();
            }
        });

        Check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                runCheck();
            }
        });

        CheckNum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                runCheckNum();
            }
        });
    }


    public void onBackPressed() {

        super.onBackPressed();

        Intent intent = new Intent(this, PopupActivity.class);
        intent.putExtra("data", "회원가입을 취소하시겠습니까");
        startActivityForResult(intent, 1);

    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                //데이터 받기
                finish();
                startActivity(new Intent(this, MainActivity.class));

            }
            else {

            }
        }
    }





    public void runRegister(){
        final String email = Email.getText().toString();
        String password = RPass.getText().toString();


        if (email == null || email.equals("")){
            Toast.makeText(this,"이메일을 입력하세요", Toast.LENGTH_SHORT).show();
            return;
        }
        if (password == null || password.equals("") || password.length()<6){
            Toast.makeText(this,"6자리 이상의 패스워드를 입력하세요", Toast.LENGTH_SHORT).show();
            return;
        }
        firebaseAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                final String uid = task.getResult().getUser().getUid();
                User user = new User();
                user.userName = Name.getText().toString();
                FirebaseDatabase.getInstance().getReference().child("users").child(uid).setValue(user);
                if(task.isSuccessful()){

                    finish();
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                }else{
                    Toast.makeText(getApplicationContext(), "회원가입 실패", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void runCheck() {
        String phoneNum = Phone.getText().toString();

    }

    public void runCheckNum(){

    }




}
