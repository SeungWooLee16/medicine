package com.example.medicine1;

public class User {
    public String userName;
    public String uid;
}
