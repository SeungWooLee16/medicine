package com.example.medicine1;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Map extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.map_layout);
    }
}
