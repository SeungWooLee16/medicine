package com.example.medicine1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    FirebaseAuth firebaseAuth;
    Button BT_login, BT_regi, BT_unlogin;
    EditText ET_mail, ET_password;
    Intent it;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        firebaseAuth = FirebaseAuth.getInstance();
        BT_login = (Button)findViewById(R.id.BT_Login);
        BT_regi = (Button)findViewById(R.id.BT_Regi);
        BT_unlogin = (Button)findViewById(R.id.BT_Unlogin);
        ET_mail = (EditText)findViewById(R.id.ET_ID);
        ET_password = (EditText)findViewById(R.id.ET_Pass);

        BT_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Login();
            }
        });
        BT_regi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Register();
            }
        });
        BT_unlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                unLogin();
            }
        });

    }







    public void Register(){

        startActivity(new Intent(this, Register.class));
    }

    public void Login(){
        final String email = ET_mail.getText().toString();
        final String password = ET_password.getText().toString();
        firebaseAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    finish();
                    it = new Intent(getApplicationContext(), Map.class);
                    it.putExtra("로그인", 0);
                    startActivity(it);
                    //new Intent(getApplicationContext()
                }else{
                    Toast.makeText(getApplicationContext(), "login failed", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void unLogin(){
        it = new Intent(this, Map.class);
        it.putExtra("로그인", 1);
        MainActivity.this.startActivity(it);
    }
}